// ============================================================
//  js/script.js  -  Kasi Kota Corner
//    1. Contact form validation - reads and checks every field
//       before treating the enquiry as ready to send
//    2. Gallery lightbox - turns Gallery.html's images into a
//       click-to-enlarge slideshow
// ============================================================

document.addEventListener("DOMContentLoaded", function () {
  setupContactForm();
  setupImageLightbox();
});

// ----------------------------------------------------------
// 1. CONTACT FORM VALIDATION
// Only index.html has #contact-form, so this does nothing
// (safely) on Gallery.html.
// ----------------------------------------------------------
function setupContactForm() {
  const form = document.getElementById("contact-form");
  if (!form) return;

  const successMessage = document.getElementById("form-success");
  const submitBtn = form.querySelector('button[type="submit"]');

  const name = document.getElementById("name");
  const email = document.getElementById("email");
  const phone = document.getElementById("phone");
  const orderType = document.getElementById("orderType");
  const message = document.getElementById("message");
  const methods = document.querySelectorAll('input[name="contactMethod"]');

  function validateName() {
    return check(name, name.value.trim().length > 0, "Please enter your name.");
  }
  function validateEmail() {
    const ok = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim());
    return check(email, ok, "Please enter a valid email address.");
  }
  function validatePhone() {
    const v = phone.value.trim();
    const ok = /^[0-9+ ]{7,15}$/.test(v);
    return check(phone, ok, "Please enter a valid phone number.");
  }
  function validateOrderType() {
    return check(orderType, orderType.value !== "", "Please choose what you'd like.");
  }
  function validateMethod() {
    const chosen = Array.from(methods).some(function (r) { return r.checked; });
    document.getElementById("contactMethod-error").textContent = chosen
      ? "" : "Please choose how we should reach you.";
    return chosen;
  }
  function validateMessage() {
    return check(message, message.value.trim().length >= 5, "Please tell us a little more (5+ characters).");
  }

  // Real-time feedback as the customer fills the form in,
  // not only once they hit submit
  name.addEventListener("blur", validateName);
  email.addEventListener("blur", validateEmail);
  phone.addEventListener("blur", validatePhone);
  orderType.addEventListener("change", validateOrderType);
  methods.forEach(function (r) { r.addEventListener("change", validateMethod); });
  message.addEventListener("blur", validateMessage);

  form.addEventListener("submit", function (event) {
    event.preventDefault(); // stop the page reloading on submit
    successMessage.classList.add("hidden");

    // This is the "interpreting" step: run every check, and only
    // proceed if every single one of them passed
    const isValid = [
      validateName(), validateEmail(), validatePhone(),
      validateOrderType(), validateMethod(), validateMessage(),
    ].every(Boolean);

    if (!isValid) return; // errors are already showing on screen

    submitBtn.disabled = true;
    submitBtn.textContent = "Sending...";

    sendEnquiry({
      name: name.value.trim(),
      email: email.value.trim(),
      phone: phone.value.trim(),
      orderType: orderType.value,
      message: message.value.trim(),
    }).finally(function () {
      submitBtn.disabled = false;
      submitBtn.textContent = "Send Enquiry";
      successMessage.classList.remove("hidden");
      form.reset();
      setTimeout(function () { successMessage.classList.add("hidden"); }, 4000);
    });
  });

  // Shared helper: marks a field invalid/valid and shows its error text
  function check(field, passed, errorText) {
    const errorEl = document.getElementById(field.id + "-error");
    field.classList.toggle("invalid", !passed);
    if (errorEl) errorEl.textContent = passed ? "" : errorText;
    return passed;
  }
}

// A plain form can't email anyone by itself - it needs a "middle
// man" service such as EmailJS. Create a free account at
// https://www.emailjs.com, add their script tag above this one,
// then uncomment the real call below. Until then this just logs
// the enquiry so the form still works end-to-end.
function sendEnquiry(data) {
  console.log("Enquiry ready to send:", data);
  // return emailjs.send("YOUR_SERVICE_ID", "YOUR_TEMPLATE_ID", data, "YOUR_PUBLIC_KEY");
  return new Promise(function (resolve) {
    setTimeout(resolve, 800);
  });
}

// ----------------------------------------------------------
// 2. GALLERY LIGHTBOX
// Targets every <img> inside .gallery-grid, so it only
// activates on Gallery.html (index.html has none).
// ----------------------------------------------------------
function setupImageLightbox() {
  const images = Array.from(document.querySelectorAll(".gallery-grid img"));
  if (images.length === 0) return;

  const overlay = document.createElement("div");
  overlay.className = "lightbox-overlay";
  overlay.innerHTML =
    '<span class="lightbox-close">&times;</span>' +
    '<span class="lightbox-prev">&#10094;</span>' +
    '<img class="lightbox-image" src="" alt="">' +
    '<span class="lightbox-next">&#10095;</span>' +
    '<span class="lightbox-counter"></span>';
  document.body.appendChild(overlay);

  const overlayImg = overlay.querySelector(".lightbox-image");
  const counter = overlay.querySelector(".lightbox-counter");
  const closeBtn = overlay.querySelector(".lightbox-close");
  const prevBtn = overlay.querySelector(".lightbox-prev");
  const nextBtn = overlay.querySelector(".lightbox-next");

  let currentIndex = 0;

  function show(index) {
    currentIndex = (index + images.length) % images.length;
    overlayImg.src = images[currentIndex].src;
    overlayImg.alt = images[currentIndex].alt;
    counter.textContent = (currentIndex + 1) + " / " + images.length;
  }
  function open(index) {
    show(index);
    overlay.classList.add("visible");
  }
  function close() {
    overlay.classList.remove("visible");
  }

  images.forEach(function (img, index) {
    img.addEventListener("click", function () { open(index); });
  });

  closeBtn.addEventListener("click", close);
  prevBtn.addEventListener("click", function () { show(currentIndex - 1); });
  nextBtn.addEventListener("click", function () { show(currentIndex + 1); });

  overlay.addEventListener("click", function (event) {
    if (event.target === overlay) close();
  });

  document.addEventListener("keydown", function (event) {
    if (!overlay.classList.contains("visible")) return;
    if (event.key === "Escape") close();
    if (event.key === "ArrowLeft") show(currentIndex - 1);
    if (event.key === "ArrowRight") show(currentIndex + 1);
  });

  // Swipe support for phones/tablets
  let touchStartX = 0;
  overlay.addEventListener("touchstart", function (event) {
    touchStartX = event.changedTouches[0].clientX;
  });
  overlay.addEventListener("touchend", function (event) {
    const deltaX = event.changedTouches[0].clientX - touchStartX;
    if (Math.abs(deltaX) < 40) return;
    if (deltaX > 0) show(currentIndex - 1);
    else show(currentIndex + 1);
  });
}
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

// Represents a product
class Product {
    private final int id;
    private final String name;
    private final double price;

    public Product(int id, String name, double price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public double getPrice() { return price; }
}

// Represents an item in the cart
class CartItem {
    private final Product product;
    private int quantity;

    public CartItem(Product product, int quantity) {
        this.product = product;
        this.quantity = quantity;
    }

    public Product getProduct() { return product; }
    public int getQuantity() { return quantity; }
    public void addQuantity(int q) { this.quantity += q; }
    public double getTotalPrice() { return quantity * product.getPrice(); }
}

// Shopping cart logic
class ShoppingCart {
    private final List<CartItem> items = new ArrayList<>();

    public void addProduct(Product product, int quantity) {
        if (quantity <= 0) {
            System.out.println("Quantity must be positive.");
            return;
        }
        
        // If item exists, increase quantity
        for (CartItem item : items) {
            if (item.getProduct().getId() == product.getId()) {
                item.addQuantity(quantity);
                System.out.println(product.getName() + " quantity updated.");
                return;
            }
        }
        
        // Else add new item
        items.add(new CartItem(product, quantity));
        System.out.println(product.getName() + " added to cart.");
    }

    public void viewCart() {
        if (items.isEmpty()) {
            System.out.println("Your cart is empty.");
            return;
        }
        
        double total = 0;
        System.out.println("\n--- Your Cart ---");
        for (CartItem item : items) {
            System.out.println(item.getProduct().getName() + " | Qty: " + item.getQuantity() +
                               " | Total: $" + item.getTotalPrice());
            total += item.getTotalPrice();
        }
        System.out.println("Cart Total: $" + total);
        System.out.println("------------------\n");
    }

    public void checkout() {
        if (items.isEmpty()) {
            System.out.println("Cannot checkout. Cart is empty.");
            return;
        }
        
        double total = 0;
        for (CartItem item : items) {
            total += item.getTotalPrice();
        }
        
        System.out.println("\nPurchase completed! Total paid: $" + total);
        items.clear();
    }
}

// Main program with menu
public class ShoppingApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Example products
        List<Product> products = new ArrayList<>();
        products.add(new Product(1, "Laptop", 799.99));
        products.add(new Product(2, "Headphones", 39.99));
        products.add(new Product(3, "Keyboard", 25.50));

        ShoppingCart cart = new ShoppingCart();

        while (true) {
            System.out.println("\n--- Menu ---");
            System.out.println("1. View Products");
            System.out.println("2. Add to Cart");
            System.out.println("3. View Cart");
            System.out.println("4. Buy / Checkout");
            System.out.println("5. Exit");
            System.out.print("Choose option: ");

            int option;
            try {
                option = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Use numbers only.");
                continue;
            }

            switch (option) {
                case 1:
                    System.out.println("\n--- Products ---");
                    for (Product p : products) {
                        System.out.println(p.getId() + ". " + p.getName() + " - $" + p.getPrice());
                    }
                    break;

                case 2:
                    System.out.print("Enter product ID: ");
                    int id;
                    try {
                        id = Integer.parseInt(scanner.nextLine());
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid ID.");
                        break;
                    }

                    Product selected = null;
                    for (Product p : products) {
                        if (p.getId() == id) {
                            selected = p;
                            break;
                        }
                    }

                    if (selected == null) {
                        System.out.println("Product not found.");
                        break;
                    }

                    System.out.print("Enter quantity: ");
                    int qty;
                    try {
                        qty = Integer.parseInt(scanner.nextLine());
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid quantity.");
                        break;
                    }

                    cart.addProduct(selected, qty);
                    break;

                case 3:
                    cart.viewCart();
                    break;

                case 4:
                    cart.checkout();
                    break;

                case 5:
                    System.out.println("Exiting application.");
                    return;

                default:
                    System.out.println("Invalid option.");
            }
        }
    }
}
